<?php

class PostController extends \BaseController {


    protected $layout='layout.style';
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */

        public function index()
    {
        //echo "hello index";
        //$u = Post::where('id_post', '>', 0)->paginate(100);
        //$u = new Post;
        //   view::make('hello')->with('u',$u);
        //$user=User::find(3)->Post;// more table and model connect tow it
        //return $user;
        //return Lang::get('reminders.user');
    }


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        $this->layout->content = view::make('hello');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */

        //////////////////////////////////////////////////////////////////


            public function store()
        {
            $ad = new Post;


            $ad->post = Input::get('post');
            $ad->user_id = Input::get('user_id');
            $ad->avatar = Input::get('avatar');

            $ad->save();
            return Redirect::back();




           /*  When to move image in file object

            $file = Input::file('avatar');
            $extension = $file->getClientOriginalName();

            $name =  time() . '.' . $extension;


            $ad ->post = Input::get('post');
            $ad->user_id = Input::get('user_id');
            $ad->avatar= $name;

            $ad->save();
            $destinationPath = base_path().'/';
            $file->move($destinationPath, $name);

            return Redirect::back();
*/


        }


             /////////////////////////////////////////////////////////////
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        $post= Post::find($id);
        $this->layout->content= view::make('post.edit')->with('post',$post);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
        $post= Post::find($id);
        $post->post  = Input::get('post');
        $post->save();
        return Redirect::back();
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
        Post::find($id)->delete();
        return Redirect::back();
	}

}