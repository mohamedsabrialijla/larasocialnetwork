<?php

class UserController extends BaseController {
    

    protected $layout='layout.style';

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
       //$us = User::all();
		//$us = User::where('id', '>', 0)->paginate(5);
		//$this->layout->content = view::make('users.index')->with('us',$us);
	   // $user=User::find(1)->adress;// more table and model connect tow it
	     //return $user;
		//return Lang::get('reminders.user');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
		return View::make('users.create');

	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//

		
		$u = new User;
		$u ->name  = Input::get('name');
		$u ->email = Input::get('email');
		$u->password =Hash::make(Input::get('password'));                       

		$u->save();

		return View::make('users.create');
	} 

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{ 
		//
		$user= User::find($id);
		$this->layout->content= view::make('users.edit')->with('user',$user);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
		$user= User::find($id);
		$user->name  = Input::get('name');
		$user->email = Input::get('email');
		$user->password = Hash::make(Input::get('password'));
		$user->save();
		return Redirect::to('user');
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
		
        
	}

}