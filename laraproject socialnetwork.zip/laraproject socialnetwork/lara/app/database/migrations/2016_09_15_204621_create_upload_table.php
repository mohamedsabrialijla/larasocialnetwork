<?php

use Illuminate\Database\Migrations\Migration;

class CreateUploadTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
        Schema::create('upload', function($table)
        {
            $table->increments('id');
            $table->string('image_url');
            $table->string('video_url');
            $table->integer('type');
            $table->integer('user_id');
            $table->timestamps();
            $table->string('remember_token', 100);
        });
    }
	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
        Schema::drop('upload');
	}

}