<?php

use Illuminate\Database\Migrations\Migration;

class CreatePostTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
        Schema::create('post', function($table)
        {
            $table->increments('id');
            $table->longtext('post');
            $table->integer('user_id');
            $table->string('avatar')->default('default.jpg');
            $table->timestamps();
            $table->string('remember_token', 100);
        });
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
        Schema::drop('post');
	}

}