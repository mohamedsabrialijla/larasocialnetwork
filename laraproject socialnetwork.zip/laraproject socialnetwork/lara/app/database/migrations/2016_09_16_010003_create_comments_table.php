<?php

use Illuminate\Database\Migrations\Migration;

class CreateCommentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
        Schema::create('comments', function($table){
            $table->increments('id');
            $table->longtext('comments');
            $table->integer('post_id');
            $table->integer('parent');
            $table->timestamps();
            $table->string('remember_token', 100);
        });
    }


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
        Schema::drop('comments');
	}

}