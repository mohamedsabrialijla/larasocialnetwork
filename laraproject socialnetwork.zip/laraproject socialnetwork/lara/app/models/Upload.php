
<?php


class Upload extends Eloquent {
    

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'upload';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @return database
	 */

	public function user()
	{
		return $this->belongsTo('User');
	}


    public function comments()
    {
        return $this->hasMany('Comments');
    }

}	