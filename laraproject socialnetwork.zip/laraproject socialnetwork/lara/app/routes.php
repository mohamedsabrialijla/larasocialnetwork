<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{

      $u = User::find(1);
     // $adr = Post::all();
	return View::make('hello')->with('u',$u);//->with('adr',$adr);
});



 // This is Login Email AND Password
/*

Route::get('login',function(){

return View::make('users.login');

});



Route::get('/', array('before'=>'auth', function(){

return 'hello dashboard';

}));

Route::post('login', function(){
 if (Auth::attempt(array('email'=> Input::get('email'), 'password'=> Input::get('password') )))
 {
 	return Redirect::intended('/');
 }
   
});

*/


Route::resource('user','UserController');

Route::get('hello','UserController@hello');
Route::post('hello','UserController@hello');

Route::resource('post','PostController');
Route::resource('upload','UploadController');

Route::resource('comments','CommentsController');