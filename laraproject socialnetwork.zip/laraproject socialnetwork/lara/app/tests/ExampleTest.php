<?php


class ExampleTest extends TestCase {



	public function test_Display_Home_page()
	{
		    $this->Call('GET', '/');

            $this->assertTrue($this->client->getResponse()->isOk());


	        //$this->assertCount(1, $crawler->filter('content:contains(content)'));
	}

}