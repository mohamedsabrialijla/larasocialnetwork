<?php


class PostControllerTest extends TestCase {



	public function testAll()
	{
		$response=$this->call('GET', 'Post');

        $this->assertTrue($response->isOk());

	}
/*
    public function testCreate()
    {
        $response=$this->call('Get', 'post/create');

        $this->assertTrue($response->isOk());
    }
    public function testSort()
    {
        $response=$this->call('Get', 'post/sort');

        $this->assertTrue($response->isOk());
    }
*/
}