@extends('layout.style')
@section('title')
    {{$u->name}} Home page
@endsection


@section('content')



    <div class="header">
        <div class="panel-body">
            <div class="row">

                <img src="{{$u->getAvatar()}}" class="img-responsive imgin">


            </div>
            <div class="name">
                <h> {{$u->name}} </h>
            </div>
        </div>

    </div>


    <div class="timeline">



        </br>
    <?php $user= new User();?>
    <!-- Input Post ///////////////////////////////////////////// -->

    {{Form::open(array('route'=>'post.store'))}}
    {{Form::label('post',' ')}}
    {{Form:: textArea('post','' ,array('class' => 'control-label col-sm-2','placeholder'=>'What Are You Say ?')) }}
    {{Form::label('user_id',' ')}}
    {{Form:: hidden('user_id',$u->id,array('class' => 'm')) }}  <!--this is hid field to return id_user from post table -->
        <br />



        <!--Uplaod image or vedio ///////////////////////////////////////-->


        <label class="custom-file">
            <input type="file" id="avatar" name="avatar" class="custom-file-input" src="/public">
            <span class="custom-file-control"></span>
        </label>

    {{ Form::submit('Post', array('class' => 'btn btn-info')) }}
    {{Form::close()}}


    <!--List Post ///////////////////////////////////////// -->

        @foreach( $u->post as $list)
            <div class="pot"></div>


            <div class="panel-body">
                <div class="row">
                    <div class="col-md-5">
                        <img src="{{$u->getAvatar()}}" class="img-responsive ">
                    </div>

                </div>
            </div>

            <div class="name1">
            {{$u->name}}  <!-- print name for user(id=1)///////////////////// -->
                <!-- occur data and time ago ///////////////////////-->
                <div class="dat">
                    {{$u->created_at}}

                    <a href="post/{{$list->id}}/edit" title="Edit" class="icon-edit"></a>
                    <a href="post/{{$list->id}}/destroy" title="Delete" class="icon-trash confirm"></a>
                </div>

            </div>



            <div class="posts"> {{$list->post}} </div>


            <?php if ($list->avatar != NULL) {  ?>
            <img src="{{$list->avatar}} " style="width: 500px; height: 250px;" />

            <?php } ?>

            <?php $post=Post::find(1); ?>
            <?php $cc=Comments::all(); ?>






        <!-- Form Input Comments ////////////////////////////////// //////////////////////////////////////////////-->

            {{Form::open(array('route'=>'comments.store','id'=>'add'))}}  <!-- By java Script when press Enter add on Database -->

            {{Form::label('comments',' ')}}
            {{Form:: text('comments','',array('id' => 'comments','placeholder'=>'write comments !!')) }}


            {{Form::label('parent',' ')}}
            {{Form:: hidden('parent','0',array('class' => 'm')) }}

            {{Form::label('post_id',' ')}}
            {{Form:: hidden('post_id',$post->id,array('class' => 'm')) }}  <!--this is hid field to return id_user from comments table -->

            {{Form::close()}}


        <!-- List Comments ////////////////////////////////////////////-->


            @foreach( $post->comments as $list)
                <?php  if(($list->parent) == 0){ ?>
                <div class="pot"></div>
                <div class="comnt">

                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-5">
                                <img src="{{$u->getAvatar()}}" class="img-responsive">
                            </div>

                        </div>
                    </div>
                    <div class="name1">
                    {{$u->name}}  <!-- print name for user(id=1)///////////////////// -->
                        <div class="dat">
                            {{$list->created_at}}
                        </div>
                    </div>
                    {{$list->comments}}

                    <div class="pt"></div>



                    <div class="rep">

                    {{Form::open(array('route'=>'comments.store','id'=>'add'))}}  <!-- By java Script when press Enter add on Database -->

                    {{Form::label('comments',' ')}}
                    {{Form:: text('comments','',array('id' => 'comments','placeholder'=>'write replies !!','class'=>'reptext')) }}


                    {{Form::label('parent',' ')}}
                    {{Form:: hidden('parent','1',array('class' => 'm')) }}

                    {{Form::label('post_id',' ')}}
                    {{Form:: hidden('post_id','1',array('class' => 'm')) }}  <!--this is hid field to return id_user from comments table -->
                    {{Form::close()}}



                    <!-- List Replies -->


                        @foreach($cc as $rep)
                            <?php if(($rep->parent) == 1 && ($list->parent) == 0){ ?>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <img src="{{$u->getAvatar()}}" class="img-responsive">
                                    </div>

                                </div>
                            </div>

                            <div class="name1">
                                {{$u->name}}

                                <div class="dat">
                                    {{$rep->created_at}}

                                </div>
                            </div>


                            {{$rep->comments}}
                            <?php } ?>

                        @endforeach

                    </div> <!--End rep -->



                </div>
                    <?php } ?>





            @endforeach  <!-- End for Comments //////////////////////////////////////////////////-->



            <br></br>

        @endforeach    <!-- End for List /post -->







        @yield('content')


    </div>

@endsection