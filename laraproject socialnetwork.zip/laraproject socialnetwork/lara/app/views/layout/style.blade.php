

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>@yield('title')</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> This is Title Stylr Layout</title>

    <!-- Bootstrap -->

    {{HTML:: style('bootstrap/css/bootstrap.min.css') }}

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
      body{
        background-color: #c9e2b3;

      }
      .header{
        width: 144%;
        height: 50px;
        margin-left: -205px;
        background-color: seagreen;
        padding-top: 10px;
      }
      .timeline {
        background-color: #eeffff;
        margin: 0px auto auto;
        min-height:100px;
        width: 800px;
        border-radius: 4px;
        padding-left: 50px;
        padding-top: 10px;
        padding-right: 40px;
      }

      .pot{
        width: inherit;
        min-height: 5px;
        background-color:#c9e2b3 ;

      }
      textArea{
        width: 800px !important;height:90px;margin-left:10px;
      }

      .btn-info {
      margin-left: 20px !important;
       margin-top: -22px !important;
     }
      .form-control{margin-top: 5px;}
      .pt{
        width: inherit;
        min-height: 1px;
        background-color:rgba(132, 157, 180, 0.34) ;
        margin-top: 3px;
      }
      .posts{margin-top: 5px;}
      input, textarea, .uneditable-input {
        width: 800px;
      }
      .dat{font-size: 10px; color: rgba(111, 132, 151, 0.51)}

      select, input[type="file"]{margin-left: 17px; margin-top: -44px;}
      .comnt{
        width: 90%;
        height: inherit;
        padding-left: 90px;
      }
      .rep{
        width: 80%;
        height: inherit;
        padding-left: 15%;
      }
      .reptext{
        width: 600px;
      }
      .name {  font-family: Helvetica;font-size: 20px;color: springgreen; margin-top: -28px; margin-left: 285px;}
      .name1{color:rgba(12, 12, 226, 0.87); margin-top: -30px; margin-left: 27px; font-family: Georgia;}
      .imgin{height: 47px; margin-top: -4px; margin-left: 250px;}
      img{height: 40px; }
      .name1 a{float: right;}
    </style>


  </head>
  <body>
    <div class="container">




    @yield('content')
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
     {{HTML:: script('https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js') }}
    <!-- Include all compiled plugins (below), or include individual files as needed -->

    {{HTML:: script('bootstrap/js/bootstrap.min.js') }}
  </body>
</html>
<script>
  $('#comments').bind('keyup', function(e) {
    if (e.which == 13) {
      $('#add').submit();
      e.preventDefault();
    }
  });

</script>