<style>
    .custom-file-input{
       margin-top: 20px;
   }


</style>

@section('content')


    {{Form::open(array('method'=>'put', 'url'=>'post/'. $post->id ))}}

    {{Form::label('post',' : ')}}
    {{Form:: text('post',$post->name)}}
    <br />
    <label class="custom-file">
        <input type="file" id="avatar" name="avatar" class="custom-file-input" src="/public">
        <span class="custom-file-control"></span>
    </label>
    {{Form::submit('Post')}}

    {{Form::close()}}

@endsection