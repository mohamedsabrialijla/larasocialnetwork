@section('content')


{{Form::open(array('method'=>'put', 'url'=>'user/'. $user->id ))}}

    {{Form::label('name','Name : ')}}
    {{Form:: text('name',$user->name)}}
    <br />

    {{Form::label('email','Email : ')}}
    {{Form:: text('email',$user->email)}}
    <br />

    {{Form::submit('Edit')}}

{{Form::close()}}

@endsection