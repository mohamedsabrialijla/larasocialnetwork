@section('content')

<table class="table table-hover">
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Password<th>
    <th>&nbsp;</th>
</tr>
@foreach( $us as $user)

<tr>
    <td>{{$user->name}}</td>
    <td>{{$user->email}}</td>
    <td>{{$user->password}}<td>
    <td>{{ HTML::link('user/'. $user->id .'/edit' ,'edit',true)}}
       
    </td>
</tr>
@endforeach

</table>
<?php echo $us->links(); ?>

@endsection





