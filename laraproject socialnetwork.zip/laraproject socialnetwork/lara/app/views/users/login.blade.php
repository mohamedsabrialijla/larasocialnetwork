<style>
    body{
        background-color: #c9e2b3;
    }

    h{
        margin-top: 10px;
    }
    form{
        margin-top: 20px;
    }
    .dev{
        margin: auto;
        height: 400px;
        width: 400px;
        margin-top: 60px;
    }
    .m{
        margin-top: 10px;
    }
    </style>
<div class="dev">
<h> This is login By Email And Password in Laravel</h>

{{Form::open()}}
{{Form::label('email','Email :')}}
{{Form::text('email')}}
</br>
{{Form::label('password','password :')}}
{{Form::text('password')}}
</br>
{{Form::submit('Login',array('class' => 'btn m'))}}

{{Form::close()}}

</div>
